package me.panavtec.drawableview.gestures.scale;

public interface ScalerListener {
  void onScaleChange(float scaleFactor);
}
